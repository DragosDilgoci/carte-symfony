import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function BookEdit() {
    const [formData, setFormData] = useState(null);
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`/api/books/${id}`)
            .then(res => res.json())
            .then(data => setFormData(data));
    }, [id]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        fetch(`/api/books/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(formData)
        })
            .then(res => {
                if (res.status === 401 || res.status === 403) {
                    alert('Acces interzis! Trebuie să fii admin pentru a edita.');
                    return;
                }
                return res.json();
            })
            .then(data => {
                if (data) {
                    alert('Carte editată!');
                    navigate('/api/books');
                }
            });
    };

    if (!formData) return <p>Loading...</p>;

    return (
        <form onSubmit={handleSubmit}>
            <input name="title" value={formData.title} onChange={handleChange} />
            <input name="author" value={formData.author} onChange={handleChange} />
            <input name="description" value={formData.description} onChange={handleChange} />
            <input name="publish_date" value={formData.publish_date} type="date" onChange={handleChange} />
            <input name="price" value={formData.price} type="number" onChange={handleChange} />
            <button type="submit">Salvează</button>
        </form>
    );
}

export default BookEdit;