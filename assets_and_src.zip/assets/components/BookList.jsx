// assets/components/BookList.jsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { isAdmin } from '../utils/auth';

function BookList() {
    const [books, setBooks] = useState([]);

    useEffect(() => {
        fetch('/api/books')
            .then((res) => res.json())
            .then((data) => setBooks(data))
            .catch((error) => console.error(error));
    }, []);

    return (
        <div>
            <h2>Lista de Cărți</h2>
            {isAdmin() && <Link to="/api/books/new">Adaugă o carte nouă</Link>}
            <ul>
                {books.map(book => (
                    <li key={book.id}>
                        <Link to={`/api/books/${book.id}`}>
                            {book.title} - {book.author}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default BookList;
