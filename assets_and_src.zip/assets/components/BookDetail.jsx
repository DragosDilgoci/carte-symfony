import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function BookDetail() {
    const { id } = useParams();
    const [book, setBook] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`/api/books/${id}`)
            .then(res => res.json())
            .then(data => setBook(data));
    }, [id]);

    const handleDelete = () => {
        fetch(`/api/books/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        })
            .then(res => {
                if (res.status === 401 || res.status === 403) {
                    alert('Nu ai voie să ștergi această carte!');
                    return;
                }
                if (res.ok) {
                    alert('Carte ștearsă!');
                    navigate('/api/books');
                }
            });
    };

    if (!book) return <p>Se încarcă...</p>;

    return (
        <div>
            <h2>{book.title}</h2>
            <p>{book.author}</p>
            <p>{book.description}</p>
            <p>{book.publish_date}</p>
            <p>{book.price} lei</p>
            <button onClick={handleDelete}>Șterge</button>
        </div>
    );
}

export default BookDetail;