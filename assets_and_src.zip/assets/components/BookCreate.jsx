import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function BookCreate() {
    const [formData, setFormData] = useState({
        title: '',
        author: '',
        description: '',
        publish_date: '',
        price: 0
    });
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        fetch('/api/books/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(formData)
        })
            .then(res => {
                if (res.status === 401 || res.status === 403) {
                    alert('Acces interzis! Trebuie să fii autentificat ca admin.');
                    return;
                }
                return res.json();
            })
            .then(data => {
                if (data) {
                    alert('Carte creată!');
                    navigate('/api/books');
                }
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="title" placeholder="Titlu" onChange={handleChange} />
            <input name="author" placeholder="Autor" onChange={handleChange} />
            <input name="description" placeholder="Descriere" onChange={handleChange} />
            <input name="publish_date" placeholder="Data publicării" type="date" onChange={handleChange} />
            <input name="price" placeholder="Preț" type="number" onChange={handleChange} />
            <button type="submit">Adaugă carte</button>
        </form>
    );
}

export default BookCreate;